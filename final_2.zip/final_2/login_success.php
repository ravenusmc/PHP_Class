<?php
 $name = $_session["username"];

?>

<h1>Hi</h1>
<a href="logout.php">LogOut</a>